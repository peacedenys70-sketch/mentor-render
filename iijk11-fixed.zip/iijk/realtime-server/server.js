const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: '*', // En production, restreindre à l'URL Next.js
    methods: ['GET', 'POST']
  }
});

// Mémoire RAM pour suivre les utilisateurs en ligne (map: userId -> socketId)
const onlineUsers = new Map();

io.on('connection', (socket) => {
  console.log(`🔌 Nouvelle connexion : ${socket.id}`);

  // 1. Authentification et mise "En ligne"
  socket.on('register_user', (userId) => {
    onlineUsers.set(userId, socket.id);
    socket.userId = userId;
    console.log(`👤 Utilisateur ${userId} est maintenant EN LIGNE (Socket: ${socket.id})`);
    
    // Notifier tous les contacts (simplifié: broadcast global)
    io.emit('user_status_change', { userId, status: 'online' });
  });

  // 2. Rejoindre une conversation privée (Room)
  socket.on('join_chat', (chatId) => {
    socket.join(chatId);
    console.log(`🚪 Socket ${socket.id} a rejoint le chat ${chatId}`);
  });

  // 3. Envoyer un message textuel/média
  socket.on('send_message', (data) => {
    // data attendu: { chatId, senderId, receiverId, content, type (text/audio/pdf) }
    console.log(`💬 Message reçu dans ${data.chatId}: ${data.content}`);
    
    // Relayer le message aux utilisateurs de la room
    io.to(data.chatId).emit('receive_message', {
      ...data,
      timestamp: new Date().toISOString(),
      status: 'sent'
    });
    
    // TODO: Appel HTTP (Axios/Fetch) vers FastAPI pour sauvegarder en BDD
  });

  // 4. Indicateur de frappe ("En train d'écrire...")
  socket.on('typing_start', (data) => {
    // data attendu: { chatId, userId }
    socket.to(data.chatId).emit('user_typing', { userId: data.userId, isTyping: true });
  });

  socket.on('typing_stop', (data) => {
    socket.to(data.chatId).emit('user_typing', { userId: data.userId, isTyping: false });
  });

  // 5. Accusés de lecture ("Vu")
  socket.on('mark_as_read', (data) => {
    // data attendu: { chatId, messageId, readerId }
    socket.to(data.chatId).emit('message_read', { messageId: data.messageId, readerId: data.readerId });
    // TODO: Informer FastAPI que le message est lu
  });

  // 6. Déconnexion
  socket.on('disconnect', () => {
    console.log(`❌ Déconnexion : ${socket.id}`);
    if (socket.userId) {
      onlineUsers.delete(socket.userId);
      io.emit('user_status_change', { userId: socket.userId, status: 'offline' });
    }
  });
});

// Route de santé
app.get('/health', (req, res) => {
  res.json({ status: 'ok', onlineUsers: onlineUsers.size });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => {
  console.log(`🚀 Serveur Temps Réel démarré sur http://localhost:${PORT}`);
});
