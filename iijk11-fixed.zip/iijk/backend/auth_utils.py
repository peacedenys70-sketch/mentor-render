from passlib.context import CryptContext
import os
from datetime import datetime, timedelta
from jose import JWTError, jwt

import hashlib

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

SECRET_KEY = "super_secret_mentorlink_key" # Should be environment variable in production
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

def _preprocess_password(password: str) -> str:
    # bcrypt nécessite une longueur maximale de 72 octets
    return hashlib.sha256(password.encode('utf-8')).hexdigest()[:72]

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(_preprocess_password(plain_password), hashed_password)

def get_password_hash(password):
    return pwd_context.hash(_preprocess_password(password))

def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt
