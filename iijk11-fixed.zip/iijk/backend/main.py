from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import models
from database import engine
from routers import auth, ai_vision, payments, matching, exams

# Crée les tables dans la base SQLite si elles n'existent pas
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="MentorLink API", description="API Backend pour MentorLink Bénin")

# Configuration CORS pour permettre au frontend Next.js de communiquer avec l'API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # En production, spécifier l'URL du frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(ai_vision.router)
app.include_router(payments.router)
app.include_router(matching.router)
app.include_router(exams.router)

@app.get("/")
def read_root():
    return {"message": "Welcome to MentorLink API"}
