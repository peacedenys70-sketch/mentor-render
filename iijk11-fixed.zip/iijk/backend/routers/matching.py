from fastapi import APIRouter, Depends, Query
from typing import List, Optional
from pydantic import BaseModel

router = APIRouter(prefix="/api/matching", tags=["matching"])

class MentorProfile(BaseModel):
    id: str
    name: str
    role: str
    school: str
    field: str
    year: str
    avatar: str
    matchScore: int
    strongPoints: List[str]
    seekingHelpIn: List[str]
    city: str
    isVerified: bool

@router.get("/recommendations", response_model=List[MentorProfile])
def get_recommendations(
    university: Optional[str] = None,
    field: Optional[str] = None
):
    """
    Moteur de Matching IA Inter-Filières Bénin
    Calcule la complémentarité entre points forts et besoins d'apprentissage.
    """
    profiles = [
        {
            "id": "1",
            "name": "Koffi Mensah",
            "role": "Étudiant Mentor",
            "school": "IFRI - UAC",
            "field": "Sécurité Informatique & IA (SIL)",
            "year": "Master 1",
            "avatar": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
            "matchScore": 96,
            "strongPoints": ["Python", "FastAPI", "Algorithmique", "Bases de données"],
            "seekingHelpIn": ["Anglais technique", "Comptabilité de gestion"],
            "city": "Abomey-Calavi",
            "isVerified": True
        },
        {
            "id": "2",
            "name": "Aïchatou Dossou",
            "role": "Étudiant Mentor",
            "school": "EPAC - UAC",
            "field": "Génie Civil & Structure",
            "year": "Licence 3",
            "avatar": "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
            "matchScore": 91,
            "strongPoints": ["Calcul de structures", "AutoCAD", "Physique Quantique"],
            "seekingHelpIn": ["Programmation Python", "Statistiques applicables"],
            "city": "Cotonou",
            "isVerified": True
        },
        {
            "id": "3",
            "name": "Dr. Martial Houngbo",
            "role": "Enseignant",
            "school": "ENEAM - UAC",
            "field": "Économie & Finance Internationale",
            "year": "Enseignant-Chercheur",
            "avatar": "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
            "matchScore": 88,
            "strongPoints": ["Analyse Financière", "Microéconomie", "Méthodologie Thèse"],
            "seekingHelpIn": [],
            "city": "Cotonou",
            "isVerified": True
        }
    ]

    if university:
        profiles = [p for p in profiles if university.lower() in p["school"].lower()]

    return profiles
