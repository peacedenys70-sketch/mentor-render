from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os

router = APIRouter(prefix="/api/payments", tags=["payments"])

FEDAPAY_SECRET_KEY = os.getenv("FEDAPAY_SECRET_KEY", "sk_sandbox_dummy_key")
FEDAPAY_API_URL = "https://sandbox-api.fedapay.com/v1"

class PaymentRequest(BaseModel):
    user_id: int
    amount: int
    description: str
    email: str

@router.post("/initiate")
def initiate_payment(payment: PaymentRequest):
    """
    Crée une transaction FedaPay (MTN/Moov) et renvoie le lien de paiement.
    """
    headers = {
        "Authorization": f"Bearer {FEDAPAY_SECRET_KEY}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "description": payment.description,
        "amount": payment.amount,
        "currency": {"iso": "XOF"},
        "callback_url": "http://localhost:3000/marketplace?payment=success",
        "customer": {
            "email": payment.email
        }
    }
    
    try:
        # Simulation d'appel API pour l'environnement de dev
        # response = requests.post(f"{FEDAPAY_API_URL}/transactions", json=payload, headers=headers)
        # response.raise_for_status()
        # data = response.json()
        
        # Bouchon (Mock) car nous n'avons pas de vraie clé API ici
        mock_transaction_id = "txn_12345"
        mock_payment_url = f"https://sandbox-checkout.fedapay.com/{mock_transaction_id}"
        
        return {
            "transaction_id": mock_transaction_id,
            "payment_url": mock_payment_url,
            "status": "pending"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail="Erreur lors de la création du paiement FedaPay")

@router.post("/webhook")
def fedapay_webhook(payload: dict):
    """
    Point de terminaison pour recevoir les notifications de FedaPay 
    (quand le paiement Mobile Money est validé).
    """
    # Analyser le payload
    event_type = payload.get("name")
    transaction_data = payload.get("entity", {})
    
    if event_type == "transaction.approved":
        # Mettre à jour la base de données (Passer le statut à 'paid' et activer l'abonnement)
        # db.query(Subscription).filter_by(txn_id=transaction_data["id"]).update({"status": "active"})
        print(f"💰 PAIEMENT REÇU ! Transaction ID: {transaction_data.get('id')}")
        
    return {"status": "Webhook processed"}
