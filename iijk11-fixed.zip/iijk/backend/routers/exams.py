from fastapi import APIRouter
from typing import List
from pydantic import BaseModel

router = APIRouter(prefix="/api/exams", tags=["exams"])

class ExamSchema(BaseModel):
    id: str
    title: str
    examType: str
    year: int
    subject: str
    series: str
    school: str
    isVerified: bool
    downloadsCount: int

@router.get("/list", response_model=List[ExamSchema])
def list_exams():
    """
    Retourne la liste des épreuves et corrigés d'examens nationaux du Bénin (BAC, BEPC, EPAC, ENEAM).
    """
    return [
        {
            "id": "ex1",
            "title": "Épreuve de Mathématiques - Session Normale 2024",
            "examType": "BAC",
            "year": 2024,
            "subject": "Mathématiques",
            "series": "Série D",
            "school": "Examen National Bénin",
            "isVerified": True,
            "downloadsCount": 1420
        },
        {
            "id": "ex2",
            "title": "Concours d'Entrée EPAC - Épreuve d'Algorithmique & Logique",
            "examType": "Concours Entrée EPAC/ENEAM",
            "year": 2023,
            "subject": "Informatique & Logique",
            "series": "Toutes séries Scientifiques",
            "school": "EPAC - UAC",
            "isVerified": True,
            "downloadsCount": 2150
        }
    ]

@router.post("/solve/{exam_id}")
def solve_exam_with_ai(exam_id: str):
    """
    Analyse l'épreuve spécifiée via le moteur IA et génère le guide méthodologique.
    """
    return {
        "exam_id": exam_id,
        "status": "success",
        "solution_summary": "Guide méthodologique et corrigé généré avec succès par FastAPI IA."
    }
