from fastapi import APIRouter, UploadFile, File, HTTPException
from typing import List, Dict
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import ai_engine
import vision

router = APIRouter(prefix="/api/intelligence", tags=["intelligence"])

@router.post("/match")
def match_students(data: dict):
    """
    Reçoit l'utilisateur courant et une liste d'étudiants, 
    et renvoie la liste triée par score de complémentarité IA.
    """
    current_user = data.get("current_user")
    all_students = data.get("all_students")
    
    if not current_user or not all_students:
        raise HTTPException(status_code=400, detail="Missing data")
        
    try:
        matches = ai_engine.match_students(current_user, all_students)
        return {"matches": matches}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/vision/crop-logo")
async def crop_logo(file: UploadFile = File(...)):
    """
    Reçoit le logo d'une école, le recadre via OpenCV, et renvoie l'image optimisée.
    """
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Invalid file type")
        
    contents = await file.read()
    try:
        cropped_bytes = vision.auto_crop_logo(contents)
        # En prod, on sauvegarderait l'image sur S3 ou en local et on renverrait l'URL
        return {"msg": "Logo recadré avec succès", "size_bytes": len(cropped_bytes)}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/vision/decode-qr")
async def decode_qr(file: UploadFile = File(...)):
    """
    Reçoit une image contenant un QR Code (ex: depuis la webcam), et extrait le texte.
    """
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Invalid file type")
        
    contents = await file.read()
    try:
        qr_data = vision.decode_qr_code(contents)
        if qr_data:
            return {"user_id_detected": qr_data}
        else:
            return {"msg": "Aucun QR Code détecté dans l'image."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
