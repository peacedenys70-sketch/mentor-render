from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
import random
import sys
import os

# Add parent directory to path to import correctly
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import models, schemas, auth_utils
from database import get_db

router = APIRouter(prefix="/api/auth", tags=["auth"])

@router.post("/register", response_model=schemas.User)
def register(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    hashed_password = auth_utils.get_password_hash(user.password)
    db_user = models.User(
        email=user.email,
        hashed_password=hashed_password,
        first_name=user.first_name,
        last_name=user.last_name,
        role=user.role,
        university=user.university,
        major=user.major
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@router.post("/login", response_model=schemas.Token)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == form_data.username).first()
    if not user or not auth_utils.verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=auth_utils.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = auth_utils.create_access_token(
        data={"sub": user.email}, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@router.post("/forgot-password")
def forgot_password(request: schemas.OTPRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.email == request.email).first()
    if not user:
        return {"msg": "If your email is in our system, you will receive an OTP."}
    
    # Generate 6 digit OTP
    code = str(random.randint(100000, 999999))
    expires = datetime.utcnow() + timedelta(minutes=15)
    
    otp_record = models.OTP(email=request.email, code=code, expires_at=expires)
    db.add(otp_record)
    db.commit()
    
    # Simulate email sending in console
    print(f"\n" + "="*50)
    print(f"📧 EMAIL SIMULÉ ENVOYÉ À : {request.email}")
    print(f"🔒 VOTRE CODE OTP EST : {code}")
    print(f"="*50 + "\n")
    
    return {"msg": "If your email is in our system, you will receive an OTP."}

@router.post("/reset-password")
def reset_password(request: schemas.OTPVerify, db: Session = Depends(get_db)):
    otp_record = db.query(models.OTP).filter(
        models.OTP.email == request.email, 
        models.OTP.code == request.code
    ).order_by(models.OTP.id.desc()).first()
    
    if not otp_record:
        raise HTTPException(status_code=400, detail="Invalid OTP")
        
    if otp_record.expires_at < datetime.utcnow():
        raise HTTPException(status_code=400, detail="OTP expired")
        
    user = db.query(models.User).filter(models.User.email == request.email).first()
    if not user:
        raise HTTPException(status_code=400, detail="User not found")
        
    user.hashed_password = auth_utils.get_password_hash(request.new_password)
    db.commit()
    
    db.delete(otp_record)
    db.commit()
    
    return {"msg": "Password updated successfully"}
