import cv2
import numpy as np
from PIL import Image
import io

def auto_crop_logo(image_bytes):
    """
    Prend les octets d'une image uploadée (Logo d'université),
    détecte les contours principaux et recadre l'image pour 
    enlever les marges inutiles.
    """
    # 1. Convertir les octets en image OpenCV
    nparr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_UNCHANGED)
    
    if img is None:
        raise ValueError("L'image n'a pas pu être décodée.")
        
    # 2. Si l'image a de la transparence (4 canaux), utiliser le canal alpha pour trouver la bounding box
    if img.shape[2] == 4:
        alpha = img[:, :, 3]
        coords = cv2.findNonZero(alpha)
    else:
        # Convertir en niveaux de gris et appliquer un seuil
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # On suppose un fond blanc, donc on inverse pour trouver les contours sombres
        _, thresh = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY_INV)
        coords = cv2.findNonZero(thresh)
        
    if coords is not None:
        x, y, w, h = cv2.boundingRect(coords)
        # Recadrer
        cropped = img[y:y+h, x:x+w]
    else:
        cropped = img # Si pas de contours trouvés, garder original

    # 3. Convertir de retour en octets (format PNG pour garder la transparence éventuelle)
    is_success, buffer = cv2.imencode(".png", cropped)
    if not is_success:
        raise ValueError("Erreur lors de l'encodage de l'image recadrée.")
        
    return buffer.tobytes()


def decode_qr_code(image_bytes):
    """
    Lit une image contenant un QR code et en extrait le texte.
    Utile pour le scanner d'amis sur le campus.
    """
    nparr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    if img is None:
        raise ValueError("L'image n'a pas pu être décodée.")
        
    detector = cv2.QRCodeDetector()
    data, bbox, straight_qrcode = detector.detectAndDecode(img)
    
    if bbox is not None and data:
        return data # Le texte contenu dans le QR Code
    else:
        return None # Aucun QR Code détecté
