from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def calculate_complementarity(student1_strengths, student1_weaknesses, student2_strengths, student2_weaknesses):
    """
    Calcule le score de complémentarité entre deux étudiants.
    L'idéal est qu'un étudiant soit fort là où l'autre est faible, et inversement.
    """
    if not student1_weaknesses or not student2_strengths:
        score1 = 0
    else:
        # Correspondance: Faiblesses E1 vs Forces E2
        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform([student1_weaknesses, student2_strengths])
        score1 = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]

    if not student2_weaknesses or not student1_strengths:
        score2 = 0
    else:
        # Correspondance: Faiblesses E2 vs Forces E1
        vectorizer2 = TfidfVectorizer()
        tfidf_matrix2 = vectorizer2.fit_transform([student2_weaknesses, student1_strengths])
        score2 = cosine_similarity(tfidf_matrix2[0:1], tfidf_matrix2[1:2])[0][0]

    # Moyenne pondérée (on convertit en pourcentage 0-100)
    final_score = ((score1 + score2) / 2) * 100
    
    # Pour simuler un comportement plus humain et éviter les scores nuls 
    # si les mots ne sont pas exactement les mêmes (à cause de TF-IDF simple),
    # on ajoute un petit boost aléatoire basé sur la filière dans une app réelle.
    
    return round(final_score, 1)

def match_students(current_user, all_students):
    """
    Prend l'utilisateur actuel et une liste d'étudiants, et retourne la liste triée par score.
    """
    matches = []
    for student in all_students:
        if student["id"] == current_user["id"]:
            continue
            
        score = calculate_complementarity(
            current_user.get("strengths", ""),
            current_user.get("weaknesses", ""),
            student.get("strengths", ""),
            student.get("weaknesses", "")
        )
        
        matches.append({
            "student": student,
            "match_score": score
        })
        
    # Trie par meilleur score
    matches.sort(key=lambda x: x["match_score"], reverse=True)
    return matches
