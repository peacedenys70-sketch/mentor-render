from pydantic import BaseModel, EmailStr
from typing import Optional

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    first_name: str
    last_name: str
    role: str = "etudiant"
    university: Optional[str] = None
    major: Optional[str] = None

class User(BaseModel):
    id: int
    email: EmailStr
    first_name: str
    last_name: str
    role: str
    university: Optional[str] = None
    major: Optional[str] = None
    
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    email: Optional[str] = None

class OTPRequest(BaseModel):
    email: EmailStr

class OTPVerify(BaseModel):
    email: EmailStr
    code: str
    new_password: str
