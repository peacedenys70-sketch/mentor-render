"use client";

import React, { useState } from "react";
import Link from "next/link";
import { registerUser } from "@/lib/api";
import { useRouter } from "next/navigation";
import { PlusCircle, Building2 } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const [role, setRole] = useState("etudiant");
  const [form, setForm] = useState({ 
    email: "", 
    password: "", 
    first_name: "", 
    last_name: "", 
    university: "", 
    custom_university: "",
    major: "" 
  });
  const [isCustomUniversity, setIsCustomUniversity] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleUniversitySelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    if (val === "AUTRE") {
      setIsCustomUniversity(true);
      setForm({ ...form, university: "" });
    } else {
      setIsCustomUniversity(false);
      setForm({ ...form, university: val, custom_university: "" });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const finalUniversity = isCustomUniversity ? form.custom_university : form.university;

    if (!finalUniversity) {
      setError("Veuillez indiquer votre université ou école.");
      setLoading(false);
      return;
    }

    try {
      await registerUser({ 
        email: form.email,
        password: form.password,
        first_name: form.first_name,
        last_name: form.last_name,
        university: finalUniversity,
        major: form.major,
        role 
      });
      router.push("/onboarding");
    } catch (err: any) {
      setError(err.message || "Erreur lors de l'inscription");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex items-center justify-center p-4 font-sans selection:bg-emerald-500 selection:text-slate-950">
      
      {/* Background Animated Glow */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-600/15 blur-[120px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] rounded-full bg-teal-500/10 blur-[130px] animate-pulse [animation-delay:2s]" />
      </div>

      <div className="max-w-md w-full bg-slate-900/90 border border-slate-800 rounded-3xl shadow-2xl p-8 relative z-10 backdrop-blur-xl">
        <div className="text-center mb-6">
          <Link href="/" className="inline-flex items-center gap-3 mb-3">
            <img src="/logo.jpg" alt="Logo MentorLink" className="w-12 h-12 rounded-xl object-cover border-2 border-emerald-400/50 shadow-lg shadow-emerald-500/20" />
            <span className="text-2xl font-black bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
              MentorLink
            </span>
          </Link>
          <h2 className="text-xl font-extrabold text-white">Rejoignez la communauté</h2>
          <p className="text-xs text-slate-400 mt-1">Créez votre compte académique au Bénin</p>
        </div>

        {/* Role selector */}
        <div className="flex gap-3 mb-6">
          {["etudiant", "professeur"].map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`flex-1 py-2.5 rounded-xl border font-bold text-xs transition-all ${
                role === r 
                  ? "border-emerald-500 bg-emerald-500/20 text-emerald-300 shadow-md shadow-emerald-500/10" 
                  : "border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700"
              }`}
            >
              {r === "etudiant" ? "Étudiant" : "Professeur"}
            </button>
          ))}
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded-xl text-xs font-semibold">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="block text-xs font-bold text-slate-300 mb-1">Prénom</label>
              <input 
                name="first_name" 
                type="text" 
                placeholder="Koffi" 
                required 
                onChange={handleChange} 
                className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 text-xs font-medium transition" 
              />
            </div>
            <div className="flex-1">
              <label className="block text-xs font-bold text-slate-300 mb-1">Nom</label>
              <input 
                name="last_name" 
                type="text" 
                placeholder="Agossou" 
                required 
                onChange={handleChange} 
                className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 text-xs font-medium transition" 
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Adresse e-mail</label>
            <input 
              name="email" 
              type="email" 
              placeholder="etudiant@uac.bj" 
              required 
              onChange={handleChange} 
              className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 text-xs font-medium transition" 
            />
          </div>

          {/* Université avec option Saisie Personnalisée si absente de la liste */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Université / École</label>
            {!isCustomUniversity ? (
              <select 
                name="university" 
                onChange={handleUniversitySelect} 
                className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 text-xs font-medium transition"
              >
                <option value="" className="bg-slate-900 text-slate-300">Sélectionnez votre établissement...</option>
                <option value="UAC (Université d'Abomey-Calavi)" className="bg-slate-900 text-slate-100">UAC (Université d'Abomey-Calavi)</option>
                <option value="EPAC" className="bg-slate-900 text-slate-100">EPAC</option>
                <option value="IFRI" className="bg-slate-900 text-slate-100">IFRI</option>
                <option value="ENEAM" className="bg-slate-900 text-slate-100">ENEAM</option>
                <option value="Pigier Bénin" className="bg-slate-900 text-slate-100">Pigier Bénin</option>
                <option value="Université de Parakou" className="bg-slate-900 text-slate-100">Université de Parakou</option>
                <option value="AUTRE" className="bg-slate-900 text-emerald-400 font-bold">➕ Mon école ne figure pas dans la liste (Ajouter)</option>
              </select>
            ) : (
              <div className="space-y-2">
                <div className="relative">
                  <input 
                    name="custom_university" 
                    type="text" 
                    placeholder="Saisissez le nom exact de votre école/institut..." 
                    required 
                    onChange={handleChange} 
                    className="w-full px-4 py-3 bg-slate-950 border border-emerald-500/60 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-emerald-400 text-xs font-medium transition" 
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setIsCustomUniversity(false)}
                  className="text-[11px] text-slate-400 hover:text-emerald-400 transition-colors underline block"
                >
                  ← Revenir à la liste des universités
                </button>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Filière</label>
            <input 
              name="major" 
              type="text" 
              placeholder="Informatique, Génie Civil, Agronomie..." 
              onChange={handleChange} 
              className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 text-xs font-medium transition" 
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Mot de passe</label>
            <input 
              name="password" 
              type="password" 
              placeholder="••••••••" 
              required 
              onChange={handleChange} 
              className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 text-xs font-medium transition" 
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black py-3 rounded-xl hover:shadow-lg hover:shadow-emerald-500/20 transition-all disabled:opacity-60 flex items-center justify-center gap-2 text-xs"
          >
            {loading ? "Création du compte..." : "Créer mon compte"}
          </button>
        </form>

        <p className="text-center mt-5 text-xs text-slate-400">
          Déjà inscrit ?{" "}
          <Link href="/auth/login" className="text-emerald-400 font-bold hover:underline">Se connecter</Link>
        </p>
      </div>
    </div>
  );
}
