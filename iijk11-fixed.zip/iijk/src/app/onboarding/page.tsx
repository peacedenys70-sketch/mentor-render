"use client";

import React, { useState } from 'react';
import Link from 'next/link';

export default function OnboardingPage() {
  const [step, setStep] = useState(1);
  const [hasSchool, setHasSchool] = useState(true);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
        
        {/* Progress Bar */}
        <div className="bg-gray-100 h-2 w-full">
          <div 
            className="bg-teal-500 h-full transition-all duration-500"
            style={{ width: `${(step / 3) * 100}%` }}
          ></div>
        </div>

        <div className="p-8 md:p-12">
          {step === 1 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-500">
              <h2 className="text-3xl font-extrabold text-gray-900 mb-2">Votre Profil Académique</h2>
              <p className="text-gray-500 mb-8">Commençons par mieux vous connaître pour configurer l'IA.</p>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Dans quelle université/école étudiez-vous ?</label>
                  <select className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none transition">
                    <option>Université d'Abomey-Calavi (UAC)</option>
                    <option>EPAC</option>
                    <option>IFRI</option>
                    <option>ENEAM</option>
                    <option>Autre...</option>
                  </select>
                </div>
                
                <div className="flex items-center gap-2">
                  <input type="checkbox" id="missing-school" className="rounded text-teal-600 focus:ring-teal-500" onChange={(e) => setHasSchool(!e.target.checked)} />
                  <label htmlFor="missing-school" className="text-sm text-gray-600">Mon école n'est pas dans la liste</label>
                </div>

                {!hasSchool && (
                  <div className="bg-teal-50 p-6 rounded-2xl border border-teal-100 space-y-4">
                    <h3 className="font-bold text-teal-800">Ajouter une nouvelle école (Crowdsourcing)</h3>
                    <input type="text" placeholder="Nom de l'école (ex: Pigier Bénin)" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none" />
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Logo de l'école (Recadrage auto par IA)</label>
                      <input type="file" className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-bold file:bg-teal-600 file:text-white hover:file:bg-teal-700" />
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-10 flex justify-end">
                <button onClick={() => setStep(2)} className="bg-teal-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-teal-700 transition">
                  Suivant
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="animate-in fade-in slide-in-from-right-4 duration-500">
              <h2 className="text-3xl font-extrabold text-gray-900 mb-2">Paramétrage du Matching</h2>
              <p className="text-gray-500 mb-8">L'IA de MentorLink vous connectera avec des étudiants complémentaires.</p>
              
              <div className="space-y-8">
                <div>
                  <label className="block text-sm font-bold text-teal-700 mb-2">Mes Points Forts (Ce que je peux enseigner)</label>
                  <p className="text-xs text-gray-500 mb-3">Séparez par des virgules (ex: Programmation C, Anglais, Mathématiques)</p>
                  <input type="text" placeholder="Ex: Algorithmique, Design UI..." className="w-full px-4 py-3 border border-teal-200 rounded-xl focus:ring-2 focus:ring-teal-500 outline-none bg-teal-50/30" />
                </div>
                
                <div>
                  <label className="block text-sm font-bold text-amber-700 mb-2">Mes Points Faibles (Ce que je veux améliorer)</label>
                  <p className="text-xs text-gray-500 mb-3">L'IA cherchera des étudiants forts dans ces domaines.</p>
                  <input type="text" placeholder="Ex: Physique quantique, Base de données..." className="w-full px-4 py-3 border border-amber-200 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none bg-amber-50/30" />
                </div>
              </div>

              <div className="mt-10 flex justify-between">
                <button onClick={() => setStep(1)} className="text-gray-500 font-bold px-6 py-3 hover:bg-gray-100 rounded-xl transition">Retour</button>
                <button onClick={() => setStep(3)} className="bg-teal-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-teal-700 transition">
                  Terminer
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="animate-in fade-in zoom-in duration-500 text-center py-10">
              <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg className="w-12 h-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="text-3xl font-extrabold text-gray-900 mb-4">Profil configuré !</h2>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">Votre profil a été analysé. Le moteur NLP a déjà trouvé 14 étudiants qui complètent parfaitement vos compétences.</p>
              
              <Link href="/explore" className="bg-gray-900 text-white font-bold px-10 py-4 rounded-xl hover:bg-black shadow-xl hover:shadow-2xl transition block w-full">
                Accéder au Campus
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
