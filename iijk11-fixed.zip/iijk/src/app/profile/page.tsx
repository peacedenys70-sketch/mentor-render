"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  QrCode, 
  Camera, 
  UserCheck, 
  Award, 
  Building2, 
  BookOpen, 
  ShieldCheck, 
  Sparkles,
  ArrowLeft,
  Upload
} from "lucide-react";

export default function ProfilePage() {
  const [showQrModal, setShowQrModal] = useState(false);
  const [showScannerModal, setShowScannerModal] = useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-16">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-900/80 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/explore" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center font-bold text-slate-950 text-xl">
              ML
            </div>
            <span className="font-extrabold text-xl bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              Mon Profil Académique
            </span>
          </Link>

          <Link href="/explore" className="text-xs font-semibold text-slate-400 hover:text-emerald-400">
            Retour au Matching
          </Link>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 pt-8">
        
        {/* Profile Card Header */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 mb-8 relative overflow-hidden shadow-2xl">
          <div className="flex flex-col sm:flex-row items-center gap-6">
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"
                alt="Photo Profil"
                className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-emerald-500/30"
              />
              <button className="absolute bottom-0 right-0 p-2 bg-emerald-500 text-slate-950 rounded-full shadow-lg hover:scale-105 transition-transform">
                <Camera className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 text-center sm:text-left">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <h1 className="text-2xl font-bold text-white flex items-center justify-center sm:justify-start gap-2">
                  Koffi Mensah <ShieldCheck className="w-5 h-5 text-emerald-400" />
                </h1>

                <div className="flex items-center justify-center gap-2">
                  <button 
                    onClick={() => setShowQrModal(true)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all"
                  >
                    <QrCode className="w-4 h-4 text-emerald-400" /> Mon Code QR
                  </button>
                  <button 
                    onClick={() => setShowScannerModal(true)}
                    className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-md shadow-emerald-500/20"
                  >
                    <Camera className="w-4 h-4" /> Scanner Camarade
                  </button>
                </div>
              </div>

              <p className="text-xs text-emerald-400 font-semibold mb-1">
                IFRI - UAC (Sécurité Informatique & IA) • Master 1
              </p>
              <p className="text-xs text-slate-400">
                Membre vérifié • Campus d'Abomey-Calavi, Bénin
              </p>
            </div>
          </div>
        </div>

        {/* Details & School Crowdsourcing section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Academic Info */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
            <h3 className="font-bold text-sm text-white mb-4 flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-emerald-400" /> Domaines d'Excellence & Besoins
            </h3>

            <div className="space-y-4 text-xs">
              <div>
                <span className="font-semibold text-slate-400 block mb-1.5">Mes Points Forts Académiques :</span>
                <div className="flex flex-wrap gap-1.5">
                  {["Python", "FastAPI", "Algorithmique", "Bases de données"].map((s, i) => (
                    <span key={i} className="px-2.5 py-1 bg-slate-800 text-emerald-300 rounded-lg border border-slate-700 font-medium">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="font-semibold text-slate-400 block mb-1.5">Recherche de l'Aide en :</span>
                <div className="flex flex-wrap gap-1.5">
                  {["Anglais Technique", "Comptabilité de Gestion"].map((s, i) => (
                    <span key={i} className="px-2.5 py-1 bg-slate-800 text-slate-300 rounded-lg border border-slate-700">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Crowdsourcing school creation & logo IA crop */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
            <h3 className="font-bold text-sm text-white mb-2 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-purple-400" /> Ajouter une École / Université au Bénin
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Si ton institut ou école privée n'est pas encore répertorié, ajoute son logo (l'IA le recadre automatiquement par Vision).
            </p>

            <form onSubmit={(e) => { e.preventDefault(); alert("Université soumise et logo recadré avec succès par l'IA Vision !"); }} className="space-y-3">
              <input
                type="text"
                placeholder="Nom complet de l'établissement (ex: ENEAM, PIGIER...)"
                className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                required
              />
              <div className="border-2 border-dashed border-slate-800 hover:border-emerald-500/50 p-4 rounded-xl text-center cursor-pointer transition-colors bg-slate-950/50">
                <Upload className="w-6 h-6 text-slate-500 mx-auto mb-1" />
                <span className="text-[11px] text-slate-400 block">Téléverser le logo (PNG / JPG)</span>
              </div>
              <button
                type="submit"
                className="w-full py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl transition-all"
              >
                Ajouter & Recadrer par IA Vision
              </button>
            </form>
          </div>
        </div>
      </main>

      {/* QR Code Modal */}
      {showQrModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-sm w-full text-center relative shadow-2xl">
            <button onClick={() => setShowQrModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white">✕</button>
            <h3 className="font-bold text-base text-white mb-1">Code QR Profil MentorLink</h3>
            <p className="text-xs text-slate-400 mb-4">Fais scanner ce code par un camarade pour t'ajouter instantanément.</p>
            
            {/* Fake QR code visualization */}
            <div className="w-48 h-48 bg-white p-4 rounded-2xl mx-auto mb-4 flex items-center justify-center border-4 border-emerald-500 shadow-lg">
              <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=MentorLink-KoffiMensah-IFRI" alt="QR Code" className="w-full h-full" />
            </div>
            <p className="text-[11px] font-bold text-emerald-400">@KoffiMensah_IFRI</p>
          </div>
        </div>
      )}

      {/* Scanner Camera Modal */}
      {showScannerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full text-center relative shadow-2xl">
            <button onClick={() => setShowScannerModal(false)} className="absolute top-4 right-4 text-slate-400 hover:text-white">✕</button>
            <h3 className="font-bold text-base text-white mb-1">Scanner Camarade de Campus</h3>
            <p className="text-xs text-slate-400 mb-4">Pointe ta caméra vers le Code QR du profil.</p>

            <div className="w-full h-56 bg-slate-950 border-2 border-dashed border-emerald-500 rounded-2xl flex flex-col items-center justify-center gap-2 mb-4 relative overflow-hidden">
              <Camera className="w-8 h-8 text-emerald-400 animate-pulse" />
              <span className="text-xs text-slate-400">Recherche de Code QR en cours...</span>
              <div className="absolute inset-x-0 h-0.5 bg-emerald-500 top-1/2 animate-ping" />
            </div>

            <button 
              onClick={() => {
                alert("Camarade identifié et ajouté à tes réseaux MentorLink !");
                setShowScannerModal(false);
              }}
              className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all"
            >
              Simuler détection du QR Code
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
