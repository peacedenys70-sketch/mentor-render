"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  BookOpen, 
  Download, 
  CheckCircle2, 
  Sparkles, 
  Search, 
  Filter, 
  FileText, 
  Award, 
  ArrowLeft,
  Bot,
  HelpCircle
} from "lucide-react";

interface Exam {
  id: string;
  title: string;
  examType: "BAC" | "BEPC" | "CEP" | "Concours Entrée EPAC/ENEAM";
  year: number;
  subject: string;
  series: string;
  school: string;
  isVerified: boolean;
  downloadsCount: number;
}

const MOCK_EXAMS: Exam[] = [
  {
    id: "ex1",
    title: "Épreuve de Mathématiques - Session Normale 2024",
    examType: "BAC",
    year: 2024,
    subject: "Mathématiques",
    series: "Série D",
    school: "Examen National Bénin",
    isVerified: true,
    downloadsCount: 1420
  },
  {
    id: "ex2",
    title: "Épreuve de Physique, Chimie et Technologie - Session 2023",
    examType: "BAC",
    year: 2023,
    subject: "Physique - Chimie",
    series: "Série C",
    school: "Examen National Bénin",
    isVerified: true,
    downloadsCount: 980
  },
  {
    id: "ex3",
    title: "Sujet de Rédaction & Dissertation Philosophie",
    examType: "BAC",
    year: 2024,
    subject: "Philosophie",
    series: "Séries A1 & A2",
    school: "Examen National Bénin",
    isVerified: true,
    downloadsCount: 810
  },
  {
    id: "ex4",
    title: "Concours d'Entrée EPAC - Épreuve d'Algorithmique & Logique",
    examType: "Concours Entrée EPAC/ENEAM",
    year: 2023,
    subject: "Informatique & Logique",
    series: "Toutes séries Scientifiques",
    school: "EPAC - UAC",
    isVerified: true,
    downloadsCount: 2150
  }
];

export default function ExamsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState("Tous");
  const [selectedExamForAi, setSelectedExamForAi] = useState<Exam | null>(null);

  const filteredExams = MOCK_EXAMS.filter((ex) => {
    const matchesSearch = 
      ex.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ex.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ex.series.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = selectedType === "Tous" || ex.examType === selectedType;
    return matchesSearch && matchesType;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-16">
      {/* Top Header */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-900/80 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/explore" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center font-bold text-slate-950 text-xl">
              ML
            </div>
            <span className="font-extrabold text-xl bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              Banque d'Épreuves Bénin
            </span>
          </Link>

          <nav className="flex items-center gap-4 text-xs font-semibold">
            <Link href="/explore" className="text-slate-400 hover:text-emerald-400">Matching IA</Link>
            <Link href="/messages" className="text-slate-400 hover:text-emerald-400">Messagerie</Link>
            <Link href="/marketplace" className="text-slate-400 hover:text-emerald-400">Marketplace</Link>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Banner Section */}
        <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-emerald-950/30 to-slate-900 border border-slate-800 p-8 mb-8 relative overflow-hidden shadow-2xl">
          <div className="max-w-2xl relative z-10">
            <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold rounded-full inline-block mb-3">
              Annale Officielle Vérifiée 2018 - 2025
            </span>
            <h1 className="text-3xl font-extrabold text-white mb-2">
              Sujets & Corrigés d'Examens du Bénin
            </h1>
            <p className="text-slate-300 text-sm mb-6">
              Télécharge les épreuves du BAC, BEPC et Concours d'entrée aux grandes écoles béninoises avec résolution assistée par IA.
            </p>

            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Rechercher une épreuve (ex: Mathématiques D 2024, Concours EPAC...)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-2">
          {["Tous", "BAC", "BEPC", "Concours Entrée EPAC/ENEAM"].map((type) => (
            <button
              key={type}
              onClick={() => setSelectedType(type)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                selectedType === type
                  ? "bg-emerald-500 text-slate-950"
                  : "bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700"
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Grid List of Exams */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredExams.map((exam) => (
            <div 
              key={exam.id}
              className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="px-2.5 py-0.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-extrabold rounded-md">
                    {exam.examType} • {exam.year}
                  </span>
                  {exam.isVerified && (
                    <span className="flex items-center gap-1 text-[10px] text-emerald-400 font-semibold bg-slate-950 px-2 py-0.5 rounded-full border border-slate-800">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Épreuve Vérifiée
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-base text-white mb-2 leading-snug">{exam.title}</h3>
                <p className="text-xs text-slate-400 mb-4">
                  Matière : <span className="text-slate-200">{exam.subject}</span> | Série : <span className="text-slate-200">{exam.series}</span>
                </p>
              </div>

              <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  📥 {exam.downloadsCount} téléchargements
                </span>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedExamForAi(exam)}
                    className="px-3 py-1.5 bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all"
                  >
                    <Bot className="w-3.5 h-3.5" /> Résoudre par IA
                  </button>
                  <button 
                    onClick={() => alert(`Téléchargement du fichier PDF : ${exam.title}`)}
                    className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs flex items-center gap-1 transition-all"
                  >
                    <Download className="w-3.5 h-3.5" /> PDF
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* AI Solver Modal */}
      {selectedExamForAi && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-xl w-full shadow-2xl relative">
            <button 
              onClick={() => setSelectedExamForAi(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              ✕
            </button>

            <div className="flex items-center gap-2 mb-4">
              <Bot className="w-6 h-6 text-purple-400" />
              <h3 className="text-lg font-bold text-white">Assistant IA — Explications & Corrigé</h3>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-300 space-y-3 mb-6">
              <p className="font-semibold text-emerald-400">{selectedExamForAi.title}</p>
              <p>
                L'IA analyse le sujet et vous génère les indications étape par étape, la méthodologie de rédaction et les pièges classiques de l'épreuve du BAC Bénin.
              </p>
            </div>

            <button 
              onClick={() => {
                alert("Génération du corrigé détaillé par le modèle IA MentorLink...");
                setSelectedExamForAi(null);
              }}
              className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-purple-600/20 transition-all"
            >
              Lancer l'analyse du sujet avec FastAPI IA
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
