"use client";

import React from "react";
import Link from "next/link";
import { 
  Sparkles, 
  Search, 
  BookOpen, 
  MessageSquare, 
  ShoppingBag, 
  CheckCircle2, 
  TrendingUp, 
  Zap, 
  ShieldCheck, 
  ArrowRight,
  GraduationCap,
  Award,
  Users
} from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-emerald-500 selection:text-slate-950">
      
      {/* Dynamic Animated Glow background */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-emerald-600/15 blur-[120px] animate-pulse" />
        <div className="absolute top-[30%] right-[-10%] w-[600px] h-[600px] rounded-full bg-teal-500/10 blur-[150px] animate-pulse [animation-delay:2s]" />
        <div className="absolute bottom-[-10%] left-[20%] w-[500px] h-[500px] rounded-full bg-purple-600/10 blur-[130px] animate-pulse [animation-delay:4s]" />
      </div>

      {/* Navigation Header */}
      <nav className="fixed w-full z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-800/80 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-3">
              <img 
                src="/logo.jpg" 
                alt="Logo MentorLink Bénin" 
                className="w-10 h-10 rounded-xl object-cover border-2 border-emerald-400/50 shadow-lg shadow-emerald-500/20" 
              />
              <span className="text-xl font-extrabold bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
                MentorLink Bénin
              </span>
            </div>

            <div className="hidden md:flex space-x-6 items-center text-sm font-medium text-slate-300">
              <Link href="/explore" className="hover:text-emerald-400 transition-colors flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-emerald-400" /> Matching IA
              </Link>
              <Link href="/marketplace" className="hover:text-emerald-400 transition-colors">Marketplace</Link>
              <Link href="/exams" className="hover:text-emerald-400 transition-colors">Épreuves Nationales</Link>
              <Link href="/messages" className="hover:text-emerald-400 transition-colors">Messagerie</Link>
              <Link href="/teacher/dashboard" className="hover:text-emerald-400 transition-colors">Espace Profs</Link>
              
              <div className="flex space-x-3 ml-4 pl-4 border-l border-slate-800">
                <Link href="/auth/login" className="text-slate-300 hover:text-emerald-400 font-semibold px-3 py-2 transition-colors">
                  Connexion
                </Link>
                <Link 
                  href="/auth/register" 
                  className="bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-bold px-5 py-2.5 rounded-xl hover:shadow-lg hover:shadow-emerald-500/25 hover:scale-105 transition-all duration-300"
                >
                  S'inscrire
                </Link>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-44 lg:pb-32 overflow-hidden z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
          
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-slate-900 border border-emerald-500/30 text-emerald-400 text-xs font-bold mb-6 shadow-xl backdrop-blur-md animate-bounce">
            <Zap className="w-4 h-4 text-emerald-400" /> Réseau Social & Matching Académique du Bénin
          </div>

          <h1 className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight mb-6 text-white leading-tight">
            Réussis ton Année Universitaire <br className="hidden sm:block" />
            avec <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">l'IA & le Mentorat</span>
          </h1>

          <p className="mt-4 text-base sm:text-lg md:text-xl text-slate-300 max-w-3xl mx-auto mb-10 leading-relaxed font-light">
            Trouve ton binôme d'études idéal (UAC, EPAC, IFRI, ENEAM, Parakou), accède aux corrigés officiels des examens et monétise tes compétences.
          </p>

          <div className="flex flex-col sm:flex-row justify-center gap-4 max-w-md mx-auto">
            <Link 
              href="/explore" 
              className="bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 font-black px-8 py-4 rounded-2xl hover:shadow-xl hover:shadow-emerald-500/25 hover:scale-105 transition-all duration-300 flex items-center justify-center gap-2 text-sm"
            >
              <Sparkles className="w-5 h-5" /> Lancer le Matching IA
            </Link>
            <Link 
              href="/marketplace" 
              className="bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 font-bold px-8 py-4 rounded-2xl transition-all duration-300 flex items-center justify-center gap-2 text-sm"
            >
              Découvrir la Marketplace
            </Link>
          </div>
        </div>
      </section>

      {/* Grid Features */}
      <section className="py-16 bg-slate-900/40 relative z-10 border-t border-b border-slate-800/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-3">Toutes les fonctionnalités de la plateforme</h2>
            <p className="text-sm text-slate-400 max-w-xl mx-auto">Conçu spécifiquement pour la communauté étudiante et les enseignants du Bénin.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Link href="/explore" className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 hover:border-emerald-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-500/5 group">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Sparkles className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2 group-hover:text-emerald-300 transition-colors">Matching IA Sémantique</h3>
              <p className="text-xs text-slate-400 leading-relaxed">Rapprochement sémantique des filières pour combler tes points faibles.</p>
            </Link>

            <Link href="/messages" className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 hover:border-teal-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-teal-500/5 group">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-teal-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <MessageSquare className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2 group-hover:text-teal-300 transition-colors">Messagerie Temps Réel</h3>
              <p className="text-xs text-slate-400 leading-relaxed">Chat avec statut en ligne, "en train d'écrire..." et cartes de services.</p>
            </Link>

            <Link href="/marketplace" className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 hover:border-purple-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/5 group">
              <div className="w-12 h-12 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-purple-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">Marketplace & Mobile Money</h3>
              <p className="text-xs text-slate-400 leading-relaxed">Abonnements 500 / 1000 FCFA payables par MTN MoMo & Moov Money.</p>
            </Link>

            <Link href="/exams" className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 hover:border-cyan-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-cyan-500/5 group">
              <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white mb-2 group-hover:text-cyan-300 transition-colors">Banque d'Épreuves Bénin</h3>
              <p className="text-xs text-slate-400 leading-relaxed">Téléchargement et résolution d'examens BAC / BEPC assistée par l'IA.</p>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 py-10 border-t border-slate-800/80 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>© 2026 MentorLink Bénin — Plateforme Académique & Marketplace Étudiante.</p>
        </div>
      </footer>
    </div>
  );
}
