"use client";

import React from "react";
import Link from "next/link";
import { 
  GraduationCap, 
  Users, 
  BookOpen, 
  DollarSign, 
  Calendar, 
  CheckCircle2, 
  ShieldAlert, 
  PlusCircle, 
  MessageSquare,
  ArrowLeft
} from "lucide-react";

export default function TeacherDashboardPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-16">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-900/80 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/explore" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center font-bold text-slate-950 text-xl">
              ML
            </div>
            <span className="font-extrabold text-xl bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              Espace Enseignant & Mentor
            </span>
          </Link>

          <span className="px-3 py-1 bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-bold rounded-full">
            Statut : Professeur Accrédité
          </span>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Top Banner Warning & Policy */}
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 mb-8 flex items-start gap-3 text-xs text-amber-200">
          <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold block mb-1">Politique de Sécurité & Éthique Académique :</span>
            Les messages privés directs hors commande officielle sont automatiquement restreints pour garantir l'équité des évaluations universitaires et la sécurité des enseignants et étudiants.
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5">
            <span className="text-xs text-slate-400 block mb-1">Solde Revenus Cumulés</span>
            <h3 className="text-2xl font-black text-emerald-400">45 000 FCFA</h3>
            <span className="text-[10px] text-slate-500 mt-1 block">Retirable via Mobile Money</span>
          </div>

          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5">
            <span className="text-xs text-slate-400 block mb-1">Étudiants Accompagnés</span>
            <h3 className="text-2xl font-black text-white">28 Élèves</h3>
            <span className="text-[10px] text-slate-400 mt-1 block">IFRI, EPAC, ENEAM</span>
          </div>

          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5">
            <span className="text-xs text-slate-400 block mb-1">Épreuves Publiées</span>
            <h3 className="text-2xl font-black text-white">12 Sujets</h3>
            <span className="text-[10px] text-emerald-400 mt-1 block">Toutes validées par modération</span>
          </div>

          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5">
            <span className="text-xs text-slate-400 block mb-1">Sessions à venir</span>
            <h3 className="text-2xl font-black text-purple-400">3 RDV</h3>
            <span className="text-[10px] text-slate-400 mt-1 block">Aujourd'hui & Demain</span>
          </div>
        </div>

        {/* Actions Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Published exams section */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-emerald-400" /> Dépôt & Modération d'Épreuves
              </h3>
              <button 
                onClick={() => alert("Ouverture du formulaire de publication d'épreuve...")}
                className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1 transition-all"
              >
                <PlusCircle className="w-3.5 h-3.5" /> Déposer une épreuve
              </button>
            </div>

            <div className="space-y-3">
              {[
                { title: "Examen Partiel Algorithmique SIL 2024", school: "IFRI - UAC", status: "Vérifiée" },
                { title: "Sujet d'Analyse Financière BAC+2", school: "ENEAM", status: "Vérifiée" },
                { title: "Travaux Dirigés Mécanique du Solide", school: "EPAC", status: "En cours" }
              ].map((item, idx) => (
                <div key={idx} className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-xs text-slate-200">{item.title}</h4>
                    <span className="text-[10px] text-slate-400">{item.school}</span>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    item.status === "Vérifiée" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400"
                  }`}>
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Student Mentoring Requests */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
            <h3 className="font-bold text-base text-white flex items-center gap-2 mb-4">
              <Users className="w-5 h-5 text-purple-400" /> Demandes d'Accompagnement Officiel
            </h3>

            <div className="space-y-3">
              {[
                { name: "Koffi Mensah", topic: "Encadrement Mémoire IA & Sécurité", school: "IFRI (Master 1)" },
                { name: "Sèna Bio", topic: "Relecture & Suivi Thèse Agronomie", school: "Univ. Parakou" }
              ].map((req, idx) => (
                <div key={idx} className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-xs text-white">{req.name}</h4>
                    <p className="text-[11px] text-slate-400">{req.topic}</p>
                    <span className="text-[10px] text-emerald-400">{req.school}</span>
                  </div>

                  <button 
                    onClick={() => alert(`Demande acceptée pour ${req.name}`)}
                    className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl shadow-md transition-all"
                  >
                    Accepter
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
