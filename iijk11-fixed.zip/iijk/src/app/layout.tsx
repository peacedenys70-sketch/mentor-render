import './globals.css';

export const metadata = {
  title: 'MentorLink Bénin — PWA Académique & Entraide',
  description: 'Plateforme académique, matching IA et marketplace pour étudiants au Bénin',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  )
}
