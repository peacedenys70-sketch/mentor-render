"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  Send, 
  Paperclip, 
  Mic, 
  Phone, 
  Video, 
  MoreVertical, 
  CheckCheck, 
  Clock, 
  FileText, 
  CheckCircle2, 
  ShoppingBag,
  Sparkles,
  ArrowLeft,
  ShieldCheck,
  Zap
} from "lucide-react";

interface ServiceCard {
  id: string;
  title: string;
  price: string;
  status: "Demandé" | "Accepté" | "Livré" | "Évalué";
}

interface Message {
  id: string;
  senderId: string;
  text?: string;
  timestamp: string;
  isRead: boolean;
  serviceCard?: ServiceCard;
}

interface Conversation {
  id: string;
  name: string;
  role: string;
  avatar: string;
  isOnline: boolean;
  lastMessage: string;
  unreadCount: number;
}

const CONVERSATIONS: Conversation[] = [
  {
    id: "1",
    name: "Koffi Mensah",
    role: "Étudiant SIL (IFRI)",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    isOnline: true,
    lastMessage: "J'ai préparé le corrigé de l'exercice d'Algorithmique.",
    unreadCount: 2
  },
  {
    id: "2",
    name: "Aïchatou Dossou",
    role: "Génie Civil (EPAC)",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
    isOnline: false,
    lastMessage: "Merci pour les explications sur le calcul de structure !",
    unreadCount: 0
  },
  {
    id: "3",
    name: "Dr. Martial Houngbo",
    role: "Professeur ENEAM",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    isOnline: true,
    lastMessage: "Votre proposition de mémoire est validée.",
    unreadCount: 0
  }
];

const INITIAL_MESSAGES: Message[] = [
  {
    id: "m1",
    senderId: "1",
    text: "Salut ! J'ai vu que tu avais besoin d'aide pour le projet FastAPI & SQLite.",
    timestamp: "14:30",
    isRead: true
  },
  {
    id: "m2",
    senderId: "me",
    text: "Oui exact ! Je bloque sur l'optimisation des requêtes de matching.",
    timestamp: "14:32",
    isRead: true
  },
  {
    id: "m3",
    senderId: "1",
    timestamp: "14:35",
    isRead: true,
    serviceCard: {
      id: "srv-101",
      title: "Coaching Python FastAPI - Session 1h",
      price: "1 500 FCFA",
      status: "Accepté"
    }
  },
  {
    id: "m4",
    senderId: "1",
    text: "J'ai validé la session. On peut commencer par passer en revue ton architecture.",
    timestamp: "14:36",
    isRead: true
  }
];

export default function MessagesPage() {
  const [activeConv, setActiveConv] = useState<Conversation>(CONVERSATIONS[0]);
  const [messages, setMessages] = useState<Message[]>(INITIAL_MESSAGES);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(true);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: "me",
      text: inputMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isRead: false
    };

    setMessages([...messages, newMsg]);
    setInputMessage("");
  };

  const updateCardStatus = (msgId: string, nextStatus: "Demandé" | "Accepté" | "Livré" | "Évalué") => {
    setMessages(messages.map(m => {
      if (m.id === msgId && m.serviceCard) {
        return {
          ...m,
          serviceCard: {
            ...m.serviceCard,
            status: nextStatus
          }
        };
      }
      return m;
    }));
  };

  return (
    <div className="h-screen bg-slate-950 text-slate-100 font-sans flex flex-col">
      {/* Top Bar */}
      <header className="h-16 bg-slate-900 border-b border-slate-800 px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <Link href="/explore" className="text-slate-400 hover:text-emerald-400 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center font-extrabold text-slate-950 text-sm">
              ML
            </div>
            <span className="font-bold text-base bg-gradient-to-r from-emerald-400 to-teal-300 bg-clip-text text-transparent">
              Messagerie & Services
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs font-semibold text-slate-400">
          <span className="hidden sm:inline flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-full border border-slate-700">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> Paiements Sécurisés MTN / Moov
          </span>
        </div>
      </header>

      {/* Main Chat Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar Conversations List */}
        <aside className="w-80 sm:w-96 border-r border-slate-800 bg-slate-900/60 flex flex-col shrink-0">
          <div className="p-3 border-b border-slate-800">
            <input 
              type="text" 
              placeholder="Rechercher une discussion..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-800/50">
            {CONVERSATIONS.map((conv) => (
              <button
                key={conv.id}
                onClick={() => setActiveConv(conv)}
                className={`w-full p-4 flex items-start gap-3 transition-colors text-left ${
                  activeConv.id === conv.id ? "bg-slate-800/80 border-l-4 border-emerald-500" : "hover:bg-slate-900/80"
                }`}
              >
                <div className="relative shrink-0">
                  <img src={conv.avatar} alt={conv.name} className="w-12 h-12 rounded-full object-cover" />
                  {conv.isOnline && (
                    <span className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-slate-900 rounded-full" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <h4 className="font-semibold text-sm text-slate-100 truncate">{conv.name}</h4>
                    <span className="text-[10px] text-slate-500">14:36</span>
                  </div>
                  <p className="text-xs text-slate-400 truncate mb-1">{conv.lastMessage}</p>
                  <span className="text-[10px] text-emerald-400/80 bg-emerald-500/10 px-2 py-0.5 rounded">
                    {conv.role}
                  </span>
                </div>

                {conv.unreadCount > 0 && (
                  <span className="bg-emerald-500 text-slate-950 text-[10px] font-bold px-1.5 py-0.5 rounded-full shrink-0">
                    {conv.unreadCount}
                  </span>
                )}
              </button>
            ))}
          </div>
        </aside>

        {/* Right Active Chat Window */}
        <section className="flex-1 flex flex-col bg-slate-950">
          {/* Active Conversation Top Bar */}
          <div className="h-16 px-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/40">
            <div className="flex items-center gap-3">
              <div className="relative">
                <img src={activeConv.avatar} alt={activeConv.name} className="w-10 h-10 rounded-full object-cover" />
                {activeConv.isOnline && (
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border border-slate-900 rounded-full" />
                )}
              </div>
              <div>
                <h3 className="font-bold text-sm text-slate-100">{activeConv.name}</h3>
                <p className="text-[11px] text-slate-400">
                  {activeConv.isOnline ? "En ligne • Réponse rapide" : "Hors ligne"}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 text-slate-400">
              <button 
                onClick={() => alert(`Lancement de l'appel audio avec ${activeConv.name}...`)}
                className="p-2 hover:bg-slate-800 rounded-lg hover:text-emerald-400 transition-colors"
              >
                <Phone className="w-4 h-4" />
              </button>
              <button 
                onClick={() => alert(`Lancement de la visioconférence avec ${activeConv.name}...`)}
                className="p-2 hover:bg-slate-800 rounded-lg hover:text-emerald-400 transition-colors"
              >
                <Video className="w-4 h-4" />
              </button>
              <button className="p-2 hover:bg-slate-800 rounded-lg hover:text-slate-200 transition-colors">
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Chat Messages Feed */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((msg) => {
              const isMe = msg.senderId === "me";

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isMe ? "items-end" : "items-start"}`}
                >
                  {msg.text && (
                    <div
                      className={`max-w-md px-4 py-2.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                        isMe
                          ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-medium rounded-br-none shadow-md shadow-emerald-500/10"
                          : "bg-slate-900 border border-slate-800 text-slate-200 rounded-bl-none"
                      }`}
                    >
                      {msg.text}
                    </div>
                  )}

                  {/* Interactive Service Card */}
                  {msg.serviceCard && (
                    <div className="w-full max-w-sm bg-slate-900 border border-emerald-500/40 rounded-2xl p-4 shadow-xl shadow-emerald-500/5 my-1">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                          <ShoppingBag className="w-3 h-3" /> Service Académique
                        </span>
                        <span className="text-xs font-bold text-slate-200">
                          {msg.serviceCard.price}
                        </span>
                      </div>

                      <h4 className="font-bold text-sm text-white mb-2">{msg.serviceCard.title}</h4>

                      {/* Status timeline */}
                      <div className="flex items-center justify-between bg-slate-950 p-2 rounded-xl mb-3 border border-slate-800">
                        <span className="text-[11px] text-slate-400">Statut :</span>
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                          msg.serviceCard.status === "Demandé" ? "bg-amber-500/20 text-amber-400" :
                          msg.serviceCard.status === "Accepté" ? "bg-blue-500/20 text-blue-400" :
                          msg.serviceCard.status === "Livré" ? "bg-emerald-500/20 text-emerald-400" :
                          "bg-purple-500/20 text-purple-400"
                        }`}>
                          {msg.serviceCard.status}
                        </span>
                      </div>

                      {/* Action buttons on card */}
                      <div className="flex gap-2">
                        {msg.serviceCard.status === "Accepté" && (
                          <button
                            onClick={() => updateCardStatus(msg.id, "Livré")}
                            className="w-full py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition-all"
                          >
                            Marquer comme Livré
                          </button>
                        )}
                        {msg.serviceCard.status === "Livré" && (
                          <button
                            onClick={() => updateCardStatus(msg.id, "Évalué")}
                            className="w-full py-1.5 bg-purple-500 hover:bg-purple-400 text-white font-bold text-xs rounded-lg transition-all"
                          >
                            Confirmer & Évaluer ⭐
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="flex items-center gap-1 text-[10px] text-slate-500 mt-1 px-1">
                    <span>{msg.timestamp}</span>
                    {isMe && <CheckCheck className="w-3 h-3 text-emerald-400" />}
                  </div>
                </div>
              );
            })}

            {/* Typing indicator */}
            {isTyping && (
              <div className="flex items-center gap-2 text-slate-400 text-xs italic bg-slate-900/60 px-3 py-1.5 rounded-full w-max border border-slate-800">
                <span>{activeConv.name} est en train d'écrire</span>
                <span className="flex gap-1">
                  <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce" />
                  <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.2s]" />
                  <span className="w-1 h-1 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.4s]" />
                </span>
              </div>
            )}
          </div>

          {/* Input Chat Box */}
          <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-800 bg-slate-900/80">
            <div className="flex items-center gap-2">
              <button 
                type="button"
                className="p-2.5 text-slate-400 hover:text-emerald-400 bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors"
              >
                <Paperclip className="w-4 h-4" />
              </button>
              <button 
                type="button"
                className="p-2.5 text-slate-400 hover:text-emerald-400 bg-slate-950 hover:bg-slate-800 rounded-xl border border-slate-800 transition-colors"
              >
                <Mic className="w-4 h-4" />
              </button>

              <input
                type="text"
                placeholder="Écrivez votre message ou proposez un service..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                className="flex-1 px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-all"
              />

              <button
                type="submit"
                className="p-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl shadow-lg shadow-emerald-500/20 transition-all"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </form>
        </section>
      </div>
    </div>
  );
}
