"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  Sparkles, 
  Search, 
  Filter, 
  BookOpen, 
  GraduationCap, 
  Building2, 
  MessageSquare, 
  UserPlus, 
  CheckCircle2, 
  Zap,
  Award,
  ChevronRight,
  TrendingUp
} from "lucide-react";

interface MentorProfile {
  id: string;
  name: string;
  role: "Étudiant Mentor" | "Enseignant";
  school: string;
  field: string;
  year: string;
  avatar: string;
  matchScore: number;
  strongPoints: string[];
  seekingHelpIn: string[];
  city: string;
  isVerified: boolean;
}

const MOCK_PROFILES: MentorProfile[] = [
  {
    id: "1",
    name: "Koffi Mensah",
    role: "Étudiant Mentor",
    school: "IFRI - UAC",
    field: "Sécurité Informatique & IA (SIL)",
    year: "Master 1",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    matchScore: 96,
    strongPoints: ["Python", "FastAPI", "Algorithmique", "Bases de données"],
    seekingHelpIn: ["Anglais technique", "Comptabilité de gestion"],
    city: "Abomey-Calavi",
    isVerified: true
  },
  {
    id: "2",
    name: "Aïchatou Dossou",
    role: "Étudiant Mentor",
    school: "EPAC - UAC",
    field: "Génie Civil & Structure",
    year: "Licence 3",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
    matchScore: 91,
    strongPoints: ["Calcul de structures", "AutoCAD", "Physique Quantique"],
    seekingHelpIn: ["Programmation Python", "Statistiques applicables"],
    city: "Cotonou",
    isVerified: true
  },
  {
    id: "3",
    name: "Dr. Martial Houngbo",
    role: "Enseignant",
    school: "ENEAM - UAC",
    field: "Économie & Finance Internationale",
    year: "Enseignant-Chercheur",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    matchScore: 88,
    strongPoints: ["Analyse Financière", "Microéconomie", "Méthodologie Thèse"],
    seekingHelpIn: [],
    city: "Cotonou",
    isVerified: true
  },
  {
    id: "4",
    name: "Sèna Bio",
    role: "Étudiant Mentor",
    school: "Université de Parakou",
    field: "Agronomie & Biotechnologie",
    year: "Licence 2",
    avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=200",
    matchScore: 85,
    strongPoints: ["Biochimie", "Génétique Végétale", "Chimie Organique"],
    seekingHelpIn: ["Biotraduction Anglais", "Informatique R"],
    city: "Parakou",
    isVerified: false
  }
];

export default function ExploreMatchingPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSchool, setSelectedSchool] = useState("Toutes");
  const [selectedRole, setSelectedRole] = useState("Tous");
  const [profiles] = useState<MentorProfile[]>(MOCK_PROFILES);

  const filteredProfiles = profiles.filter((p) => {
    const matchesSearch = 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.field.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.strongPoints.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesSchool = selectedSchool === "Toutes" || p.school.includes(selectedSchool);
    const matchesRole = selectedRole === "Tous" || p.role === selectedRole;

    return matchesSearch && matchesSchool && matchesRole;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-16">
      {/* Header / Banner Navigation */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-900/80 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <img 
              src="/logo.jpg" 
              alt="Logo MentorLink Bénin" 
              className="w-10 h-10 rounded-xl object-cover border-2 border-emerald-400/50 shadow-lg shadow-emerald-500/20" 
            />
            <span className="font-extrabold text-xl bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
              MentorLink Bénin
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
            <Link href="/explore" className="text-emerald-400 flex items-center gap-1 font-semibold">
              <Sparkles className="w-4 h-4" /> Matching IA
            </Link>
            <Link href="/messages" className="hover:text-emerald-400 transition-colors">Messagerie</Link>
            <Link href="/marketplace" className="hover:text-emerald-400 transition-colors">Marketplace</Link>
            <Link href="/exams" className="hover:text-emerald-400 transition-colors">Épreuves Nationales</Link>
            <Link href="/teacher/dashboard" className="hover:text-emerald-400 transition-colors">Espace Profs</Link>
          </nav>

          <div className="flex items-center gap-3">
            <Link 
              href="/onboarding"
              className="px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-all shadow-md shadow-emerald-500/20"
            >
              Mon Profil
            </Link>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Hero Section Page */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-emerald-950/40 to-slate-900 border border-slate-800 p-6 sm:p-10 mb-8 shadow-2xl">
          <div className="absolute top-0 right-0 -mt-12 -mr-12 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="max-w-3xl relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold mb-4">
              <Zap className="w-3.5 h-3.5" /> Algorithme de Match NLP Inter-Filières Bénin
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-3">
              Trouve ton Binôme ou Mentor Académique Optimal
            </h1>
            <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
              Connecte-toi avec des étudiants de l'UAC, Université de Parakou, Pigier, ENEAM, IFRI, EPAC dont les points forts comblent tes besoins d'apprentissage.
            </p>

            {/* Search Bar */}
            <div className="flex flex-col sm:flex-row items-center gap-3">
              <div className="relative w-full">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Recherche par matière (ex: Python, Mathématiques, Génie Civil...)"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-slate-900/90 border border-slate-700/80 rounded-xl text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 text-sm transition-all"
                />
              </div>
              <button className="w-full sm:w-auto px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm rounded-xl transition-all shadow-lg shadow-emerald-500/20 whitespace-nowrap">
                Filtrer avec l'IA
              </button>
            </div>
          </div>
        </div>

        {/* Filters bar */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold text-slate-400 flex items-center gap-1 mr-2">
              <Filter className="w-3.5 h-3.5" /> Universités:
            </span>
            {["Toutes", "IFRI", "EPAC", "ENEAM", "Parakou"].map((school) => (
              <button
                key={school}
                onClick={() => setSelectedSchool(school)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedSchool === school
                    ? "bg-emerald-500 text-slate-950 font-bold"
                    : "bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700"
                }`}
              >
                {school}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-400 mr-2">Rôle:</span>
            {["Tous", "Étudiant Mentor", "Enseignant"].map((role) => (
              <button
                key={role}
                onClick={() => setSelectedRole(role)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  selectedRole === role
                    ? "bg-teal-500 text-slate-950 font-bold"
                    : "bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700"
                }`}
              >
                {role}
              </button>
            ))}
          </div>
        </div>

        {/* Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProfiles.map((profile) => (
            <div 
              key={profile.id}
              className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all duration-300 hover:shadow-xl hover:shadow-emerald-500/5 group flex flex-col justify-between"
            >
              <div>
                {/* Profile Header */}
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <img
                        src={profile.avatar}
                        alt={profile.name}
                        className="w-14 h-14 rounded-full object-cover border-2 border-emerald-500/30 group-hover:border-emerald-400 transition-colors"
                      />
                      {profile.isVerified && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 bg-slate-950 rounded-full absolute bottom-0 right-0 fill-slate-950" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-bold text-base text-white group-hover:text-emerald-300 transition-colors">
                        {profile.name}
                      </h3>
                      <p className="text-xs text-slate-400 flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-slate-500" /> {profile.school}
                      </p>
                      <span className="inline-block mt-1 text-[11px] font-medium text-emerald-400/90 bg-emerald-500/10 px-2 py-0.5 rounded">
                        {profile.role} • {profile.year}
                      </span>
                    </div>
                  </div>

                  {/* Match Score Badge */}
                  <div className="flex flex-col items-end">
                    <div className="flex items-center gap-1 bg-gradient-to-r from-emerald-500 to-teal-400 text-slate-950 px-2.5 py-1 rounded-xl font-extrabold text-xs shadow-md">
                      <TrendingUp className="w-3.5 h-3.5" />
                      {profile.matchScore}%
                    </div>
                    <span className="text-[10px] text-slate-400 mt-1">Compatibilité</span>
                  </div>
                </div>

                <div className="text-xs text-slate-300 font-medium mb-3">
                  🎓 <span className="text-slate-200">{profile.field}</span>
                </div>

                {/* Strong points */}
                <div className="mb-3">
                  <span className="text-[11px] font-semibold text-slate-400 block mb-1.5 uppercase tracking-wider">
                    Points forts (Excellence) :
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {profile.strongPoints.map((skill, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 bg-slate-800 border border-slate-700 text-emerald-300 text-[11px] rounded-md font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Needs help in */}
                {profile.seekingHelpIn.length > 0 && (
                  <div className="mb-4">
                    <span className="text-[11px] font-semibold text-slate-400 block mb-1.5 uppercase tracking-wider">
                      Recherche de l'aide en :
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {profile.seekingHelpIn.map((skill, idx) => (
                        <span
                          key={idx}
                          className="px-2 py-0.5 bg-slate-800/60 text-slate-300 text-[11px] rounded-md border border-slate-700/50"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-800/80 flex items-center gap-2 mt-2">
                <Link
                  href={`/messages?user=${profile.id}`}
                  className="flex-1 py-2 px-3 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:border-emerald-500/50 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all"
                >
                  <MessageSquare className="w-3.5 h-3.5" /> Discuter
                </Link>
                <button 
                  onClick={() => alert(`Demande d'entraide envoyée à ${profile.name} ! (Le mentorat est 100% gratuit)`)}
                  className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1 transition-all"
                >
                  <UserPlus className="w-3.5 h-3.5" /> Mentorat Gratuit
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
