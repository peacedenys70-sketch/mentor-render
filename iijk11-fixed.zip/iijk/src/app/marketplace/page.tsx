"use client";

import React, { useState } from "react";
import Link from "next/link";
import { 
  ShoppingBag, 
  Check, 
  Sparkles, 
  Zap, 
  ShieldCheck, 
  Star, 
  UserCheck, 
  CreditCard, 
  PhoneCall, 
  BookOpen, 
  Laptop, 
  FileCheck,
  ArrowLeft,
  X
} from "lucide-react";

interface ServiceOffer {
  id: string;
  title: string;
  category: "Cours & Entraide" | "Dépannage PC & Dev" | "Rédaction & Correction" | "Design & Graphisme";
  authorName: string;
  authorSchool: string;
  price: string;
  rating: number;
  salesCount: number;
  isTopFeed: boolean;
  avatar: string;
}

const MOCK_SERVICES: ServiceOffer[] = [
  {
    id: "s1",
    title: "Correction & Mise en page aux normes Thèse / Mémoire BAC+3 à BAC+5",
    category: "Rédaction & Correction",
    authorName: "Koffi Mensah",
    authorSchool: "IFRI - UAC",
    price: "2 500 FCFA",
    rating: 4.9,
    salesCount: 38,
    isTopFeed: true,
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "s2",
    title: "Dépannage & Installation Environnement Dev (Python, Node.js, VSCode)",
    category: "Dépannage PC & Dev",
    authorName: "Aïchatou Dossou",
    authorSchool: "EPAC - UAC",
    price: "1 500 FCFA",
    rating: 5.0,
    salesCount: 24,
    isTopFeed: true,
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "s3",
    title: "Séances Intensives de Mathématiques et Physiques BAC & Licence 1",
    category: "Cours & Entraide",
    authorName: "Sèna Bio",
    authorSchool: "Univ. Parakou",
    price: "2 000 FCFA",
    rating: 4.8,
    salesCount: 15,
    isTopFeed: false,
    avatar: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=200"
  }
];

export default function MarketplacePage() {
  const [selectedCategory, setSelectedCategory] = useState("Toutes");
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<"EXPOSANT" | "PREMIUM" | null>(null);
  const [phoneOperator, setPhoneOperator] = useState<"MTN" | "MOOV" | "CELTIIS">("MTN");
  const [phoneNumber, setPhoneNumber] = useState("");

  const filteredServices = selectedCategory === "Toutes" 
    ? MOCK_SERVICES 
    : MOCK_SERVICES.filter(s => s.category === selectedCategory);

  const handleSubscribe = (plan: "EXPOSANT" | "PREMIUM") => {
    setSelectedPlan(plan);
    setShowPaymentModal(true);
  };

  const processPayment = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Demande de paiement de ${selectedPlan === "EXPOSANT" ? "500 FCFA" : "1 000 FCFA"} envoyée sur le numéro ${phoneNumber} (${phoneOperator}). Veuillez valider avec votre code PIN MoMo.`);
    setShowPaymentModal(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans pb-16">
      {/* Top Header */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-slate-900/80 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link href="/explore" className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center font-bold text-slate-950 text-xl">
              ML
            </div>
            <span className="font-extrabold text-xl bg-gradient-to-r from-emerald-400 to-cyan-400 bg-clip-text text-transparent">
              Marketplace Bénin
            </span>
          </Link>

          <div className="flex items-center gap-4 text-xs font-semibold">
            <Link href="/explore" className="text-slate-400 hover:text-emerald-400">
              Matching IA
            </Link>
            <Link href="/messages" className="text-slate-400 hover:text-emerald-400">
              Messagerie
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        
        {/* Pricing Tiers Hero Section */}
        <div className="mb-12">
          <div className="text-center max-w-2xl mx-auto mb-8">
            <span className="px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-bold rounded-full uppercase tracking-wider inline-block mb-3">
              Monétise tes Compétences sur le Campus
            </span>
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white mb-3">
              Offres & Micro-Services Étudiants
            </h1>
            <p className="text-slate-400 text-sm">
              Propose tes cours, ton aide en informatique ou en rédaction et reçois tes paiements directement par Mobile Money.
            </p>
          </div>

          {/* Formules Tarifaires Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {/* Formule 1: Gratuite */}
            <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Formule Découverte</span>
                <h3 className="text-2xl font-black text-white mt-1 mb-2">0 FCFA <span className="text-xs font-normal text-slate-400">/ mois</span></h3>
                <p className="text-xs text-slate-400 mb-6">Idéal pour rechercher et commander des prestations auprès des camarades.</p>
                <ul className="space-y-3 text-xs text-slate-300 mb-6">
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Consultation illimitée</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Contact direct par messagerie</li>
                  <li className="flex items-center gap-2 text-slate-500"><X className="w-4 h-4" /> Publication de micro-services</li>
                </ul>
              </div>
              <button disabled className="w-full py-2.5 bg-slate-800 text-slate-400 font-bold text-xs rounded-xl cursor-not-allowed">
                Plan Actuel
              </button>
            </div>

            {/* Formule 2: Exposant (500 FCFA) */}
            <div className="bg-gradient-to-b from-slate-900 to-slate-900/90 border border-emerald-500/40 rounded-3xl p-6 flex flex-col justify-between shadow-xl relative">
              <span className="absolute -top-3 right-6 px-3 py-1 bg-emerald-500 text-slate-950 font-black text-[10px] uppercase rounded-full tracking-wider shadow-md">
                Recommandé
              </span>
              <div>
                <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Formule Exposant</span>
                <h3 className="text-2xl font-black text-white mt-1 mb-2">500 FCFA <span className="text-xs font-normal text-slate-400">/ mois</span></h3>
                <p className="text-xs text-slate-400 mb-6">Pour les étudiants proposant leurs compétences sur les campus du Bénin.</p>
                <ul className="space-y-3 text-xs text-slate-300 mb-6">
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Publication de 3 Annonces</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Encaissement par Mobile Money</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-400" /> Badge Vendeur Vérifié</li>
                </ul>
              </div>
              <button 
                onClick={() => handleSubscribe("EXPOSANT")}
                className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition-all"
              >
                S'abonner (500 FCFA / mois)
              </button>
            </div>

            {/* Formule 3: Premium Top of Feed (1000 FCFA) */}
            <div className="bg-slate-900/60 border border-purple-500/30 rounded-3xl p-6 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-purple-400 uppercase tracking-wider">Formule Premium Top</span>
                <h3 className="text-2xl font-black text-white mt-1 mb-2">1 000 FCFA <span className="text-xs font-normal text-slate-400">/ mois</span></h3>
                <p className="text-xs text-slate-400 mb-6">Maximum de visibilité avec positionnement prioritaire en tête de fil.</p>
                <ul className="space-y-3 text-xs text-slate-300 mb-6">
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-purple-400" /> Annonces Illimitées</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-purple-400" /> Positionnement ⚡ Top of Feed</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-purple-400" /> Support & Recommandations IA</li>
                </ul>
              </div>
              <button 
                onClick={() => handleSubscribe("PREMIUM")}
                className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-extrabold text-xs rounded-xl shadow-lg shadow-purple-600/20 transition-all"
              >
                Passer Premium (1 000 FCFA)
              </button>
            </div>
          </div>
        </div>

        {/* Services Listings Grid */}
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
            <h2 className="text-xl font-bold text-white flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-emerald-400" /> Micro-Services Disponibles
            </h2>

            {/* Category Filter */}
            <div className="flex flex-wrap gap-2">
              {["Toutes", "Cours & Entraide", "Dépannage PC & Dev", "Rédaction & Correction"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    selectedCategory === cat
                      ? "bg-emerald-500 text-slate-950 font-bold"
                      : "bg-slate-900 text-slate-300 border border-slate-800 hover:border-slate-700"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredServices.map((service) => (
              <div 
                key={service.id}
                className="bg-slate-900/70 border border-slate-800 rounded-2xl p-5 hover:border-slate-700 transition-all group flex flex-col justify-between relative"
              >
                {service.isTopFeed && (
                  <span className="absolute top-4 right-4 bg-purple-500/20 border border-purple-500/40 text-purple-300 text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1">
                    ⚡ TOP OF FEED
                  </span>
                )}

                <div>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    {service.category}
                  </span>

                  <h3 className="font-bold text-sm text-white group-hover:text-emerald-300 transition-colors mb-3 leading-snug">
                    {service.title}
                  </h3>

                  <div className="flex items-center gap-3 mb-4">
                    <img src={service.avatar} alt={service.authorName} className="w-9 h-9 rounded-full object-cover" />
                    <div>
                      <h4 className="text-xs font-bold text-slate-200">{service.authorName}</h4>
                      <p className="text-[10px] text-slate-400">{service.authorSchool}</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block">Tarif :</span>
                    <span className="text-base font-extrabold text-emerald-400">{service.price}</span>
                  </div>

                  <Link
                    href={`/messages?service=${service.id}`}
                    className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-md transition-all"
                  >
                    Commander
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Mobile Money Payment Modal */}
      {showPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl relative">
            <button 
              onClick={() => setShowPaymentModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-6">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-3">
                <CreditCard className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white">Paiement Mobile Money Bénin</h3>
              <p className="text-xs text-slate-400">
                Abonnement {selectedPlan === "EXPOSANT" ? "Exposant (500 FCFA)" : "Premium (1 000 FCFA)"}
              </p>
            </div>

            <form onSubmit={processPayment} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-2">Choisis ton Réseau :</label>
                <div className="grid grid-cols-3 gap-2">
                  {(["MTN", "MOOV", "CELTIIS"] as const).map((op) => (
                    <button
                      type="button"
                      key={op}
                      onClick={() => setPhoneOperator(op)}
                      className={`py-2 rounded-xl text-xs font-bold transition-all border ${
                        phoneOperator === op
                          ? "bg-emerald-500 text-slate-950 border-emerald-400"
                          : "bg-slate-950 text-slate-400 border-slate-800"
                      }`}
                    >
                      {op}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">Numéro Mobile Money (Bénin) :</label>
                <input
                  type="tel"
                  placeholder="ex: +229 97 00 00 00"
                  required
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-500/20 transition-all mt-4"
              >
                Payer {selectedPlan === "EXPOSANT" ? "500 FCFA" : "1 000 FCFA"} via {phoneOperator}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
