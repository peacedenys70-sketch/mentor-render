/**
 * API Client centralisé pour communiquer avec le Backend FastAPI
 * URL de base : http://localhost:8000
 */

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

// --- Authentification ---

export async function registerUser(data: {
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  role: string;
  university?: string;
  major?: string;
}) {
  const res = await fetch(`${API_BASE_URL}/api/auth/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || "Erreur inscription");
  }
  return res.json();
}

export async function loginUser(email: string, password: string) {
  const formData = new URLSearchParams();
  formData.append("username", email);
  formData.append("password", password);

  const res = await fetch(`${API_BASE_URL}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: formData.toString(),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || "Email ou mot de passe incorrect");
  }
  const data = await res.json();
  // Stocker le token JWT
  if (typeof window !== "undefined") {
    localStorage.setItem("mentorlink_token", data.access_token);
  }
  return data;
}

export async function forgotPassword(email: string) {
  const res = await fetch(`${API_BASE_URL}/api/auth/forgot-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  });
  if (!res.ok) throw new Error("Erreur lors de l'envoi du code OTP");
  return res.json();
}

export async function resetPassword(email: string, code: string, new_password: string) {
  const res = await fetch(`${API_BASE_URL}/api/auth/reset-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, code, new_password }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || "Code OTP invalide ou expiré");
  }
  return res.json();
}

// --- IA & Matching ---

export async function getMatches(currentUser: object, allStudents: object[]) {
  const res = await fetch(`${API_BASE_URL}/api/intelligence/match`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ current_user: currentUser, all_students: allStudents }),
  });
  if (!res.ok) throw new Error("Erreur moteur de matching");
  return res.json();
}

// --- Paiements ---

export async function initiatePayment(data: {
  user_id: number;
  amount: number;
  description: string;
  email: string;
}) {
  const res = await fetch(`${API_BASE_URL}/api/payments/initiate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Erreur lors de l'initiation du paiement");
  return res.json();
}

// --- Helpers ---

export function getToken(): string | null {
  if (typeof window !== "undefined") {
    return localStorage.getItem("mentorlink_token");
  }
  return null;
}

export function logout() {
  if (typeof window !== "undefined") {
    localStorage.removeItem("mentorlink_token");
    window.location.href = "/auth/login";
  }
}
