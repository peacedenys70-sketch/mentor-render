/**
 * Hook React pour la messagerie en temps réel via Socket.io
 * Connecte le frontend au serveur Node.js sur le port 4000.
 */

import { useEffect, useRef, useState } from "react";

// En dev : npm install socket.io-client dans le projet Next.js
// import { io, Socket } from "socket.io-client";

const REALTIME_SERVER = "http://localhost:4000";

export interface Message {
  id: string;
  senderId: string;
  chatId: string;
  content: string;
  type: "text" | "audio" | "pdf";
  timestamp: string;
  status: "sent" | "delivered" | "read";
}

export function useChat(chatId: string, userId: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState<string[]>([]);
  const socketRef = useRef<any>(null);

  useEffect(() => {
    // Décommentez après avoir installé socket.io-client :
    // const socket = io(REALTIME_SERVER);
    // socketRef.current = socket;
    // 
    // socket.emit("register_user", userId);
    // socket.emit("join_chat", chatId);
    // 
    // socket.on("receive_message", (msg: Message) => {
    //   setMessages(prev => [...prev, msg]);
    //   // Marquer comme lu automatiquement si le chat est ouvert
    //   socket.emit("mark_as_read", { chatId, messageId: msg.id, readerId: userId });
    // });
    //
    // socket.on("user_typing", (data: { userId: string; isTyping: boolean }) => {
    //   if (data.userId !== userId) setIsTyping(data.isTyping);
    // });
    //
    // socket.on("user_status_change", (data: { userId: string; status: string }) => {
    //   if (data.status === "online") setOnlineUsers(prev => [...prev, data.userId]);
    //   else setOnlineUsers(prev => prev.filter(id => id !== data.userId));
    // });
    //
    // return () => { socket.disconnect(); };
  }, [chatId, userId]);

  const sendMessage = (content: string, type: "text" | "audio" | "pdf" = "text") => {
    if (!socketRef.current) return;
    socketRef.current.emit("send_message", {
      chatId,
      senderId: userId,
      content,
      type,
    });
  };

  const startTyping = () => {
    socketRef.current?.emit("typing_start", { chatId, userId });
  };

  const stopTyping = () => {
    socketRef.current?.emit("typing_stop", { chatId, userId });
  };

  return { messages, isTyping, onlineUsers, sendMessage, startTyping, stopTyping };
}
